﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.Samples.Kinect.WpfViewers
{
    class MotionUtils
    {
        Dictionary<String, State> bodyStates;
        Dictionary<String, State> handStates;
        Dictionary<String, State> legStates;

        public MotionUtils()
        {
            List<State> states = new List<State>();
            bodyStates = initBodyStates();
            handStates = initHandStates();
            legStates = initLegStates();
        }

        public State getNextBodyState(String stateName, String action)
        {
            //get state by name
            State currentState = new State("");
            if (bodyStates.TryGetValue(stateName, out currentState))
            {
                Transition transition;
                if (currentState.getTransitions().TryGetValue(action, out transition))
                {
                    return transition.getNewState();
                }
            }
            Console.Out.WriteLine("!!!!!!!!!!");
            return currentState;
        }

        public State getNextHandState(String stateName, String action)
        {
            //get state by name
            State currentState = new State("");
            if (handStates.TryGetValue(stateName, out currentState))
            {
                Transition transition;
                if (currentState.getTransitions().TryGetValue(action, out transition))
                {
                    return transition.getNewState();
                }
            }
            Console.Out.WriteLine("?????????");
            return currentState;
        }

        public State getNextLegState(String stateName, String action)
        {
            //get state by name
            State currentState = new State("");
            if (legStates.TryGetValue(stateName, out currentState))
            {
                Transition transition;
                if (currentState.getTransitions().TryGetValue(action, out transition))
                {
                    return transition.getNewState();
                }
            }
            Console.Out.WriteLine("::::::::::::::::");
            return currentState;
        }

        public Dictionary<String, State> initBodyStates()
        {
            Dictionary<String, State> bodyList = new Dictionary<String, State>();

            State state1 = new State(Constants.stateType.INTERMEDIATE, "");
            state1.setName("D");
            State state2 = new State(Constants.stateType.FINAL, "lateral bending");
            state2.setName("Al.D");
            State state3 = new State(Constants.stateType.FINAL, "lifting side");
            state3.setName("D.Al");
            State state4 = new State(Constants.stateType.FINAL, "raise from seated");
            state4.setName("D.AfAs");
            State state5 = new State(Constants.stateType.FINAL, "front bending");
            state5.setName("Af.D");
            State state6 = new State(Constants.stateType.FINAL, "settling down");
            state6.setName("As.Af");
            State state7 = new State(Constants.stateType.INTERMEDIATE, "");
            state7.setName("Af.As");
            State state8 = new State(Constants.stateType.FINAL, "side bending while seated");
            state8.setName("Al.As");
            State state9 = new State(Constants.stateType.FINAL, "bending front seated");
            state9.setName("Af.AlAs");
            State state10 = new State(Constants.stateType.FINAL, "lateral bending while seated");
            state10.setName("Al.AfAs");
            State state11 = new State(Constants.stateType.FINAL, "lift from the side seated");
            state11.setName("As.AlAs");
            State state12 = new State(Constants.stateType.FINAL, "lifting the front");
            state12.setName("D.Af");
            State state13 = new State(Constants.stateType.FINAL, "bending sideways in front stoop");
            state13.setName("Al.Af");
            State state14 = new State(Constants.stateType.FINAL, "circular motion - front stoop of lateral bending");
            state14.setName("Af.Al");
            State state15 = new State(Constants.stateType.FINAL, "lift front of bending seated");
            state15.setName("As.AfAs");
            State state16 = new State(Constants.stateType.FINAL, "Cadere");
            state16.setName("C");

            state1.getTransitions().Add("straight", new Transition(0.2, "straight", state1));
            state1.getTransitions().Add("bent front", new Transition(0.2, "bent front", state5));
            state1.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state2));
            state1.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state1.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state2.getTransitions().Add("straight", new Transition(0.2, "straight", state3));
            state2.getTransitions().Add("bent front", new Transition(0.2, "bent front", state14));
            state2.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state2));
            state2.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state2.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state3.getTransitions().Add("straight", new Transition(0.2, "straight", state3));
            state3.getTransitions().Add("bent front", new Transition(0.2, "bent front", state5));
            state3.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state2));
            state3.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state3.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state4.getTransitions().Add("straight", new Transition(0.2, "straight", state4));
            state4.getTransitions().Add("bent front", new Transition(0.2, "bent front", state5));
            state4.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state2));
            state4.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state4.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state5.getTransitions().Add("straight", new Transition(0.2, "straight", state12));
            state5.getTransitions().Add("bent front", new Transition(0.2, "bent front", state5));
            state5.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state13));
            state5.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state5.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state6.getTransitions().Add("straight", new Transition(0.2, "straight", state6));
            state6.getTransitions().Add("bent front", new Transition(0.2, "bent front", state7));
            state6.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state8));
            state6.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state6.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state7.getTransitions().Add("straight", new Transition(0.2, "straight", state4));
            state7.getTransitions().Add("bent front", new Transition(0.2, "bent front", state7));
            state7.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state10));
            state7.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state7.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state8.getTransitions().Add("straight", new Transition(0.2, "straight", state6));
            state8.getTransitions().Add("bent front", new Transition(0.2, "bent front", state9));
            state8.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state8));
            state8.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state8.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state9.getTransitions().Add("straight", new Transition(0.2, "straight", state15));
            state9.getTransitions().Add("bent front", new Transition(0.2, "bent front", state9));
            state9.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state10));
            state9.getTransitions().Add("placed", new Transition(0.2, "placed", state15));
            state9.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state10.getTransitions().Add("straight", new Transition(0.2, "straight", state11));
            state10.getTransitions().Add("bent front", new Transition(0.2, "bent front", state9));
            state10.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state10));
            state10.getTransitions().Add("placed", new Transition(0.2, "placed", state11));
            state10.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state11.getTransitions().Add("straight", new Transition(0.2, "straight", state6));
            state11.getTransitions().Add("bent front", new Transition(0.2, "bent front", state7));
            state11.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state8));
            state11.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state11.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state12.getTransitions().Add("straight", new Transition(0.2, "straight", state12));
            state12.getTransitions().Add("bent front", new Transition(0.2, "bent front", state5));
            state12.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state2));
            state12.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state12.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state13.getTransitions().Add("straight", new Transition(0.2, "straight", state3));
            state13.getTransitions().Add("bent front", new Transition(0.2, "bent front", state14));
            state13.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state13));
            state13.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state13.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state14.getTransitions().Add("straight", new Transition(0.2, "straight", state12));
            state14.getTransitions().Add("bent front", new Transition(0.2, "bent front", state14));
            state14.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state13));
            state14.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state14.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            state15.getTransitions().Add("straight", new Transition(0.2, "straight", state6));
            state15.getTransitions().Add("bent front", new Transition(0.2, "bent front", state7));
            state15.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state8));
            state15.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state15.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            // TODO: modifica starea urmatoare
            state16.getTransitions().Add("straight", new Transition(0.2, "straight", state1));
            state16.getTransitions().Add("bent front", new Transition(0.2, "bent front", state5));
            state16.getTransitions().Add("bent sideways", new Transition(0.2, "bent sideways", state2));
            state16.getTransitions().Add("placed", new Transition(0.2, "placed", state6));
            state16.getTransitions().Add("lying", new Transition(0.2, "lying", state16));

            bodyList.Add(state1.getName(), state1);
            bodyList.Add(state2.getName(), state2);
            bodyList.Add(state3.getName(), state3);
            bodyList.Add(state4.getName(), state4);
            bodyList.Add(state5.getName(), state5);
            bodyList.Add(state6.getName(), state6);
            bodyList.Add(state7.getName(), state7);
            bodyList.Add(state8.getName(), state8);
            bodyList.Add(state9.getName(), state9);
            bodyList.Add(state10.getName(), state10);
            bodyList.Add(state11.getName(), state11);
            bodyList.Add(state12.getName(), state12);
            bodyList.Add(state13.getName(), state13);
            bodyList.Add(state14.getName(), state14);
            bodyList.Add(state15.getName(), state15);
            bodyList.Add(state16.getName(), state16);
            
            return bodyList;
        }

        public Dictionary<String, State> initHandStates()
        {
            Dictionary<String, State> handList = new Dictionary<String, State>();

            State state1 = new State(Constants.stateType.INTERMEDIATE, "");
            state1.setName("Lc");
            State state2 = new State(Constants.stateType.FINAL, "front lift");
            state2.setName("Rf.Lc");
            State state3 = new State(Constants.stateType.FINAL, "decent from the front");
            state3.setName("Lc.Rf");
            State state4 = new State(Constants.stateType.FINAL, "lateral raise");
            state4.setName("Rl.Lc");
            State state5 = new State(Constants.stateType.FINAL, "decent from the side");
            state5.setName("Lc.Rl");
            State state6 = new State(Constants.stateType.FINAL, "lift up");
            state6.setName("Rs");
            State state7 = new State(Constants.stateType.FINAL, "lower front from the top");
            state7.setName("Rf.Rs");
            State state8 = new State(Constants.stateType.FINAL, "lower the top to the side");
            state8.setName("Rl.Rs");
            State state9 = new State(Constants.stateType.FINAL, "kick punch");
            state9.setName("Rf.Rl");
            State state10 = new State(Constants.stateType.FINAL, "circular movement of the front side");
            state10.setName("Rl.Rf");

            state1.getTransitions().Add("sides", new Transition(0.2, "sides", state1));
            state1.getTransitions().Add("high front", new Transition(0.2, "high front", state2));
            state1.getTransitions().Add("high side", new Transition(0.2, "high side", state4));
            state1.getTransitions().Add("high top", new Transition(0.2, "high top", state6));

            state2.getTransitions().Add("sides", new Transition(0.2, "sides", state3));
            state2.getTransitions().Add("high front", new Transition(0.2, "high front", state2));
            state2.getTransitions().Add("high side", new Transition(0.2, "high side", state10));
            state2.getTransitions().Add("high top", new Transition(0.2, "high top", state6));

            state3.getTransitions().Add("sides", new Transition(0.2, "sides", state3));
            state3.getTransitions().Add("high front", new Transition(0.2, "high front", state2));
            state3.getTransitions().Add("high side", new Transition(0.2, "high side", state4));
            state3.getTransitions().Add("high top", new Transition(0.2, "high top", state6));

            state4.getTransitions().Add("sides", new Transition(0.2, "sides", state5));
            state4.getTransitions().Add("high front", new Transition(0.2, "high front", state9));
            state4.getTransitions().Add("high side", new Transition(0.2, "high side", state4));
            state4.getTransitions().Add("high top", new Transition(0.2, "high top", state6));

            state5.getTransitions().Add("sides", new Transition(0.2, "sides", state5));
            state5.getTransitions().Add("high front", new Transition(0.2, "high front", state2));
            state5.getTransitions().Add("high side", new Transition(0.2, "high side", state4));
            state5.getTransitions().Add("high top", new Transition(0.2, "high top", state6));

            state6.getTransitions().Add("sides", new Transition(0.2, "sides", state1));
            state6.getTransitions().Add("high front", new Transition(0.2, "high front", state7));
            state6.getTransitions().Add("high side", new Transition(0.2, "high side", state8));
            state6.getTransitions().Add("high top", new Transition(0.2, "high top", state6));

            state7.getTransitions().Add("sides", new Transition(0.2, "sides", state3));
            state7.getTransitions().Add("high front", new Transition(0.2, "high front", state7));
            state7.getTransitions().Add("high side", new Transition(0.2, "high side", state10));
            state7.getTransitions().Add("high top", new Transition(0.2, "high top", state6));

            state8.getTransitions().Add("sides", new Transition(0.2, "sides", state5));
            state8.getTransitions().Add("high front", new Transition(0.2, "high front", state9));
            state8.getTransitions().Add("high side", new Transition(0.2, "high side", state8));
            state8.getTransitions().Add("high top", new Transition(0.2, "high top", state6));

            state9.getTransitions().Add("sides", new Transition(0.2, "sides", state3));
            state9.getTransitions().Add("high front", new Transition(0.2, "high front", state9));
            state9.getTransitions().Add("high side", new Transition(0.2, "high side", state10));
            state9.getTransitions().Add("high top", new Transition(0.2, "high top", state6));

            state10.getTransitions().Add("sides", new Transition(0.2, "sides", state5));
            state10.getTransitions().Add("high front", new Transition(0.2, "high front", state9));
            state10.getTransitions().Add("high side", new Transition(0.2, "high side", state10));
            state10.getTransitions().Add("high top", new Transition(0.2, "high top", state6));


            handList.Add(state1.getName(), state1);
            handList.Add(state2.getName(), state2);
            handList.Add(state3.getName(), state3);
            handList.Add(state4.getName(), state4);
            handList.Add(state5.getName(), state5);
            handList.Add(state6.getName(), state6);
            handList.Add(state7.getName(), state7);
            handList.Add(state8.getName(), state8);
            handList.Add(state9.getName(), state9);
            handList.Add(state10.getName(), state10);

            return handList;
        }

        public Dictionary<String, State> initLegStates()
        {
            
            Dictionary<String, State> legList = new Dictionary<String, State>();
            
            State state1 = new State(Constants.stateType.INTERMEDIATE, "");
            state1.setName("D");
            State state2 = new State(Constants.stateType.INTERMEDIATE, "");
            state2.setName("I.D");
            State state3 = new State(Constants.stateType.FINAL, "step");
            state3.setName("D.I");
            State state4 = new State(Constants.stateType.FINAL, "front lift");
            state4.setName("Rf.D");
            State state5 = new State(Constants.stateType.FINAL, "lateral raise");
            state5.setName("Rl.D");
            State state6 = new State(Constants.stateType.FINAL, "circular motion towards the front");
            state6.setName("Rf.Rl");
            State state7 = new State(Constants.stateType.FINAL, "decent from the front");
            state7.setName("D.Rf");
            State state8 = new State(Constants.stateType.INTERMEDIATE, "");
            state8.setName("I");
            State state9 = new State(Constants.stateType.FINAL, "decent from the side");
            state9.setName("D.Rl");
            State state10 = new State(Constants.stateType.FINAL, "circular motion towards the sides");
            state10.setName("Rl.Rf");

            state1.getTransitions().Add("straight", new Transition(0.2, "straight", state1));
            state1.getTransitions().Add("high front", new Transition(0.2, "high front", state4));
            state1.getTransitions().Add("high side", new Transition(0.2, "high side", state5));
            state1.getTransitions().Add("bent", new Transition(0.2, "bent", state2));

            state2.getTransitions().Add("straight", new Transition(0.2, "straight", state3));
            state2.getTransitions().Add("high front", new Transition(0.2, "high front", state4));
            state2.getTransitions().Add("high side", new Transition(0.2, "high side", state5));
            state2.getTransitions().Add("bent", new Transition(0.2, "bent", state2));
            
            state3.getTransitions().Add("straight", new Transition(0.2, "straight", state3));
            state3.getTransitions().Add("high front", new Transition(0.2, "high front", state4));
            state3.getTransitions().Add("high side", new Transition(0.2, "high side", state5));
            state3.getTransitions().Add("bent", new Transition(0.2, "bent", state2));
            
            state4.getTransitions().Add("straight", new Transition(0.2, "straight", state7)); // 3
            state4.getTransitions().Add("high front", new Transition(0.2, "high front", state4));
            state4.getTransitions().Add("high side", new Transition(0.2, "high side", state10));
            state4.getTransitions().Add("bent", new Transition(0.2, "bent", state8)); // 2

            state5.getTransitions().Add("straight", new Transition(0.2, "straight", state9));
            state5.getTransitions().Add("high front", new Transition(0.2, "high front", state6));
            state5.getTransitions().Add("high side", new Transition(0.2, "high side", state5));
            state5.getTransitions().Add("bent", new Transition(0.2, "bent", state8)); // sau 10

            state6.getTransitions().Add("straight", new Transition(0.2, "straight", state7));
            state6.getTransitions().Add("high front", new Transition(0.2, "high front", state6));
            state6.getTransitions().Add("high side", new Transition(0.2, "high side", state10));
            state6.getTransitions().Add("bent", new Transition(0.2, "bent", state8)); // sau 10 !

            state7.getTransitions().Add("straight", new Transition(0.2, "straight", state7));
            state7.getTransitions().Add("high front", new Transition(0.2, "high front", state4));
            state7.getTransitions().Add("high side", new Transition(0.2, "high side", state5));
            state7.getTransitions().Add("bent", new Transition(0.2, "bent", state2)); // sau 10 !

            state8.getTransitions().Add("straight", new Transition(0.2, "straight", state1)); // !!
            state8.getTransitions().Add("high front", new Transition(0.2, "high front", state4)); // !!
            state8.getTransitions().Add("high side", new Transition(0.2, "high side", state5)); // !!
            state8.getTransitions().Add("bent", new Transition(0.2, "bent", state8));

            state9.getTransitions().Add("straight", new Transition(0.2, "straight", state9));
            state9.getTransitions().Add("high front", new Transition(0.2, "high front", state4));
            state9.getTransitions().Add("high side", new Transition(0.2, "high side", state5));
            state9.getTransitions().Add("bent", new Transition(0.2, "bent", state2));

            state10.getTransitions().Add("straight", new Transition(0.2, "straight", state9)); //7
            state10.getTransitions().Add("high front", new Transition(0.2, "high front", state6));
            state10.getTransitions().Add("high side", new Transition(0.2, "high side", state10));
            state10.getTransitions().Add("bent", new Transition(0.2, "bent", state8)); // sau 2


            legList.Add(state1.getName(), state1);
            legList.Add(state2.getName(), state2);
            legList.Add(state3.getName(), state3);
            legList.Add(state4.getName(), state4);
            legList.Add(state5.getName(), state5);
            legList.Add(state6.getName(), state6);
            legList.Add(state7.getName(), state7);
            legList.Add(state8.getName(), state8);
            legList.Add(state9.getName(), state9);
            legList.Add(state10.getName(), state10);

            return legList;
             
        }
    }

}
